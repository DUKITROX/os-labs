#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <err.h>
#include <unistd.h>
#include <sys/wait.h>
#include <ctype.h>

#define MAXLINE 1024

int setargs(char *args, char **argv)
{
	int count = 0;

	// A completar por el alumno: usar isspace para comprobar si un caracter es
	// un espacio


	return count;
}

// Programa de test de la función setargs. No hay que modificarlo.
int main(int argc, char **argv)
{
	char line[] = "ls -l    -t";
	int cargc;
	char **cargv;

	if (argc > 1)
		errx(EXIT_FAILURE, "usage: %s");

	cargc = setargs(line, NULL);
	cargv = malloc((cargc + 1) * sizeof(char *));
	if (cargv == NULL)
		err(EXIT_FAILURE, "argv malloc");
	setargs(line, cargv);
	cargv[cargc] = NULL;

	for (int i = 0; i < cargc; i++)
		printf("argv[%d] = %s\n", i, cargv[i]);

	return 0;
}
