#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <err.h>
#include <unistd.h>
#include <sys/wait.h>
#include <ctype.h>

#define MAXLINE 1024

int setargs(char *args, char **argv)
{
	int count = 0;

	// Sustituir por el código del apartado a

	return count;
}

int main(int argc, char **argv)
{
	FILE *in;
	char linebuf[MAXLINE];

	// Completar por el alumno: usar fgets para leer el stream de entrada (in)
	// línea a línea, usando linebuf como buffer para almacenar la línea.
	






	return 0;
}
