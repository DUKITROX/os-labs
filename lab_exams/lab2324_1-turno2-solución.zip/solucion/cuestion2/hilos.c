#include <pthread.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

//#define APARTADO_C

#ifdef APARTADO_C
int fd = -1;
pthread_mutex_t m=PTHREAD_MUTEX_INITIALIZER;
#endif

void *threadfn(void* arg){
    int* id=arg;
    int n=*id;
    char buf[10];
#ifndef APARTADO_C 
    int fd=open("output.txt", O_WRONLY);

    if (fd==-1){
        perror("open() failed");
        pthread_exit((void*)1);
    }
#endif
#ifdef APARTADO_C
    pthread_mutex_lock(&m);
#endif
    lseek(fd,n*5,SEEK_SET);
    if (n==0)
        strcpy(buf,"00000");
    else
        sprintf(buf,"%d",n*11111);
    write(fd,buf,5);
#ifdef APARTADO_C
    pthread_mutex_unlock(&m);
#endif
    free(id);
    return (void*)0;
}


int main(int argc, char* argv[]){
    pthread_t descr[10];
    int i=0;
#ifndef APARTADO_C
    int fd;
#endif
    fd=open("output.txt", O_RDWR | O_CREAT | O_TRUNC, 0600);
    char buf[10];
    int n;

    if (fd==-1){
        perror("open() failed");
        exit(1);
    }

    for (i=0;i<10;i++){
        int* id=malloc(sizeof(int));
        *id=i;
        pthread_create(&descr[i],NULL,threadfn,id);
    }
    
    for (i=0;i<10;i++)
        pthread_join(descr[i],NULL);

    printf("@@@ Contenido del fichero @@@\n");
    fflush(stdout);
#ifdef APARTADO_C
    lseek(fd, 0, SEEK_SET);
#endif
    while((n=read(fd,buf,sizeof(buf)))>0)
        write(1,buf,n);
    printf("\n------------------------------\n");
    fflush(stdout);
}

