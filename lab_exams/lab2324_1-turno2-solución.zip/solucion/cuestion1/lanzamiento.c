#include <stdio.h>
#include <getopt.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

pid_t run_command(const char* command){
    pid_t pid;

    pid=fork();

    if (pid==0){
        execlp("/bin/bash","/bin/bash","-c",command,NULL);
        perror("exec failed");
        exit(1);
    } 
    return pid;
}

#define MAX_COMMANDS 20
#define MAX_CHARS_LINE 128

int main(int argc, char* argv[]){
	int opt;
    char* arg;
    int status;
    pid_t pid;
    unsigned char script_mode=0;
    unsigned char cmd_mode=0;
    unsigned char background=0;
    pid_t pids[MAX_COMMANDS];

    /* Clear pids */
    memset(pids,0,sizeof(pids));

	while ((opt = getopt(argc, argv, "hx:s:b")) != -1)
	{
		switch (opt)
		{
		case 'h':
            printf("Usage: %s [ -x <command> | -s <script> | -b]\n", argv[0]);
			break;
		case 'x':
			arg = optarg;
            cmd_mode = 1;
			break;
		case 's':
			arg = optarg;
            script_mode = 1;
			break;
		case 'b':
            background = 1;
			break;
		default:
			exit(2);
		}
	}

    if (cmd_mode){
        pid=run_command(arg);

        if (pid<0)
            exit(1);

        while(wait(&status) == pid);

        exit(status);
    } else if (script_mode) {
        FILE* fp;
        int i=0;
        char buf[MAX_CHARS_LINE];
        fp=fopen(arg,"r");
        int cmd_count=0;

        if (!fp){
            perror("couldn't open script");
            exit(1);
        }

        while (fgets(buf,MAX_CHARS_LINE,fp)){
            printf("@@ Running command #%d: %s",i,buf);
            pids[i]=run_command(buf);

            if (pids[i]<0)
                exit(1);

            if (!background){
                while(wait(&status) == pids[i]);
                printf("@@ Command #%d terminated (pid: %d, status: %d)\n",i,pids[i],status);
            }
            i++;
        }
        cmd_count=i;

        if (background){
            /* Wait until all comands terminate */
            while((pid=wait(&status)) != -1){
                /* determine command id */
                i=0;
                while (i<cmd_count && pid!=pids[i])
                    i++;

                if (i!=cmd_count){
                    printf("@@ Command #%d terminated (pid: %d, status: %d)\n",i,pids[i],status);
                    pids[i]=0;
                }

            }
        }
    }


    return 0;
}