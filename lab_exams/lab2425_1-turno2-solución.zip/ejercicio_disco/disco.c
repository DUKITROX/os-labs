#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <err.h>


#define CAPACITY 5
#define MAX_CLIENTS_AFTER_CLEANING 3
#define VIPSTR(vip) ((vip) ? "  vip  " : "not vip")

int num_clients = 0;
int nturn = 0;
int nticket = 0;
int vturn = 0;
int vticket = 0;

int num_clients_inside = 0;
int vip_waiting = 0;
int clients_after_cleaning = 0;
int clean_pending = 0;
#define PARTE_C
#ifdef PARTE_C
int finished = 0;
#endif

pthread_mutex_t m;
pthread_cond_t cond_vip;
pthread_cond_t cond_normal;
pthread_cond_t cond_clean;

typedef struct {
	int id;
	int isvip;
} client_arg_t;


void enter_normal_client(int id)
{
	int myticket;

	pthread_mutex_lock(&m);
	myticket = nticket++;
	while (myticket != nturn || vip_waiting || num_clients_inside >= CAPACITY ||
		  (clients_after_cleaning>=MAX_CLIENTS_AFTER_CLEANING && clean_pending)) {
		printf("Client %2d (not vip) waiting on the queue\n", id);
		pthread_cond_wait(&cond_normal, &m);
	}
	num_clients_inside++;
	clients_after_cleaning++;	
	nturn++;
	pthread_cond_broadcast(&cond_normal);
	printf("Client %2d (not vip) entering the disco\n", id);
	pthread_mutex_unlock(&m);
}

void enter_vip_client(int id)
{
	int myticket;

	pthread_mutex_lock(&m);
	myticket = vticket++;
	vip_waiting++;
	while (myticket != vturn || num_clients_inside >= CAPACITY || 
		  (clients_after_cleaning>=MAX_CLIENTS_AFTER_CLEANING && clean_pending)) {
		printf("Client %2d (  vip  ) waiting on the queue\n", id);
		pthread_cond_wait(&cond_vip, &m);
	}
	vip_waiting--;
	num_clients_inside++;
	clients_after_cleaning++;
	vturn++;
	if (vip_waiting)
		pthread_cond_broadcast(&cond_vip);
	else
		pthread_cond_broadcast(&cond_normal);
	printf("Client %2d (  vip  ) entering the disco\n", id);
	pthread_mutex_unlock(&m);
}

void dance(int id, int isvip)
{
	printf("Client %2d (%s) dancing in disco\n", id, VIPSTR(isvip));
	sleep((rand() % 3) + 1);
}

void disco_exit(int id, int isvip)
{
	int myticket;

	pthread_mutex_lock(&m);
	num_clients_inside--;
	if (num_clients_inside==0 && clean_pending==1)
		pthread_cond_signal(&cond_clean);

	if (vip_waiting)
		pthread_cond_broadcast(&cond_vip);
	else
		pthread_cond_broadcast(&cond_normal);
	printf("Client %2d (%s) exits the disco\n", id, VIPSTR(isvip));
	pthread_mutex_unlock(&m);
}

void *client(void *arg)
{
	client_arg_t *pca = (client_arg_t *)arg;

	printf("Starting client %2d\n", pca->id, VIPSTR(pca->isvip));

	if (pca->isvip)
		enter_vip_client(pca->id);
	else
		enter_normal_client(pca->id);
	dance(pca->id, pca->isvip);
	disco_exit(pca->id, pca->isvip);

	free(pca);

	return NULL;
}

void enter_cleaning(){
	pthread_mutex_lock(&m);
	clean_pending=1;

	printf("Cleaning thread waiting to enter disco\n");
	while (clients_after_cleaning<MAX_CLIENTS_AFTER_CLEANING || num_clients_inside > 0) {
		pthread_cond_wait(&cond_clean,&m);
#ifdef PARTE_C
		if (finished)
			break;
#endif
	}


	pthread_mutex_unlock(&m);
}

void exit_cleaning(){
	pthread_mutex_lock(&m);

	clean_pending=0;
	// Reset cleaners....
	clients_after_cleaning=0;

	if (vip_waiting)
		pthread_cond_broadcast(&cond_vip);
	else
		pthread_cond_broadcast(&cond_normal);

	pthread_mutex_unlock(&m);
}

void* cleaning_thread(void* arg){
#ifdef PARTE_C
   while(!finished)
#else
   while(1)
#endif
{
        enter_cleaning();
#ifdef PARTE_C
		if (finished)
			break;
#endif
        //Limpiar la discoteca
        printf("Cleaning...\n");
        sleep(2);
        printf("Done!\n");
        exit_cleaning();
   }
   return NULL;
 }


int main(int argc, char *argv[])
{
	int i,isvip;
	client_arg_t *ca;
	pthread_t *tid;
	pthread_t limpieza;
	FILE* fs;

	if (argc != 2)
		errx(EXIT_FAILURE, "usage %s filename\n\tError: filename missing\n",
				argv[0]);

	fs = fopen(argv[1], "r");
	if (fs == NULL)
		err(EXIT_FAILURE, "Open file %s", argv[1]);

	if (fscanf(fs, "%d\n", &num_clients) != 1)
		err(EXIT_FAILURE, "parsing number of clients");

	tid = malloc(num_clients * sizeof(pthread_t));
	if (tid == NULL)
		err(EXIT_FAILURE, "malloc pthread_t");

	pthread_mutex_init(&m, NULL);
	pthread_cond_init(&cond_normal, NULL);
	pthread_cond_init(&cond_vip, NULL);
	pthread_cond_init(&cond_clean, NULL);

	pthread_create(&limpieza, NULL, cleaning_thread, NULL);


	for (i = 0; i < num_clients; i++) {
		ca = malloc(sizeof(client_arg_t));
		ca->id = i;
		if (fscanf(fs, "%d\n", &isvip) != 1)
			err(EXIT_FAILURE, "parsing vip nature of client %d", i);
		ca->isvip = isvip;
		//printf("client %d is %s\n", i, VIPSTR(isvip));
		pthread_create(&tid[i], NULL, client, ca);
	}

	fclose(fs);
	fs = NULL;

	for (i = 0; i < num_clients; i++)
		pthread_join(tid[i], NULL);

#ifdef PARTE_C
	pthread_mutex_lock(&m);
	finished=1;
	pthread_cond_signal(&cond_clean);
	pthread_mutex_unlock(&m);
	pthread_join(limpieza, NULL);
#else
	pthread_cancel(limpieza);
#endif
	

	pthread_mutex_destroy(&m);
	pthread_cond_destroy(&cond_normal);
	pthread_cond_destroy(&cond_vip);
	pthread_cond_destroy(&cond_clean);

	free(tid);
	tid = NULL;

	return 0;
}
