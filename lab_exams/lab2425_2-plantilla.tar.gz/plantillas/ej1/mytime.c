#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <err.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>

/* ayudas para el apartado c **************************************/
#define TV_SEC(tv) ((tv).tv_sec)
#define TV_MSEC(tv) ((tv).tv_usec / 1000)

void timeval_diff(struct timeval *start, struct timeval *elapsed)
{
	elapsed->tv_sec -= start->tv_sec;
	if (elapsed->tv_usec < start->tv_usec) {
		elapsed->tv_sec--;
		elapsed->tv_usec += 1000000;
	}
	elapsed->tv_usec -= start->tv_usec;
}
/******************************************************************/

int run_command(char *cmd)
{
	pid_t pid;
	int ret = 0;


	return ret;
}


int main(int argc, char **argv)
{
	int ret = 0;



	return ret;
}
