#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>

#define MAX_SBUFFER_SIZE 4
#define MAX_LINE_LENGTH 256

char *shared_buffer[MAX_SBUFFER_SIZE];

int main(int argc, char *argv[])
{

    return 0;
}
