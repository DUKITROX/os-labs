#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/mman.h>

#include "graph.h"

struct task *tasks;

void wait_for_predecesors(int id)
{
	int i;

	//wait for predecesors
	for (i = 0; i < tasks[id].pred; i++) {
//		printf("Task %d waiting\n", id);
		sem_wait(&tasks[id].s);
	}
}

void notify_successors(int id)
{
	int i;

	//signal successors
	for (i = 0; i < MAXPROC; i++)
		if (tasks[id].next[i]) {
//			printf("Task %d notifying task %d\n", id, i);
			sem_post(&tasks[i].s);
		}
}

void task_body(int id)
{
	wait_for_predecesors(id);

	printf("Task %d running pid %u parent %u\n", id, (unsigned) getpid(),
			(unsigned) getppid());

	notify_successors(id);

	_exit(0);
}

void create_tasks(struct task *tasks, int n)
{
	int i;

	for (i = 0; i < n; i++) {
		if (!tasks[i].valid)
			continue;
		tasks[i].pid = fork();
		if (tasks[i].pid == 0)
			task_body(i);
	}
}

int main(int argc, char** argv)
{
	FILE *f;
	int i,j;

	tasks = mmap(NULL, sizeof(struct task)*MAXPROC, PROT_READ|PROT_WRITE,
			MAP_SHARED|MAP_ANONYMOUS, 0, 0);

#ifndef STATIC_GRAPH
	if (argc < 2)
		errx(-1, "usage: %s filename", argv[0]);

	parse_graph(argv[1], tasks);
#else
	memcpy(tasks, tasks_static, sizeof(struct task) * MAXPROC);
#endif

	for (i = 0; i < MAXPROC; i++) {
		if (!tasks[i].valid)
			continue;
		// Inicialización de predecesores
		for (j = 0; j < MAXPROC; j++)
			if (tasks[i].next[j])
				tasks[j].pred++;
		// Inicialización de recursos de sincronización
		sem_init(&tasks[i].s, 1, 0);
	}

	print_graph(tasks, MAXPROC);

	printf("Original process with pid %d\n", (unsigned) getpid());
	create_tasks(tasks, MAXPROC);
	while (wait(NULL) != -1);
}

