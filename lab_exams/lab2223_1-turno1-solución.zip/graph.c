#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <errno.h>

#include "graph.h"

struct task tasks_static[MAXPROC] = {
//                        0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15
	{.valid = 1, .next = {0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, .id = 0}, // 0: 1 2 3
	{.valid = 1, .next = {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, .id = 1}, // 1: 4
	{.valid = 1, .next = {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, .id = 2}, // 2: 5
	{.valid = 1, .next = {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, .id = 3}, // 3: 5
	{.valid = 1, .next = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, .id = 4}, // 4:
	{.valid = 1, .next = {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, .id = 5}, // 5: 4
	0
};

#ifdef PARSE_STRSEP

void parse_graph(char *fname, struct task *tasks)
{
	FILE *f;

	f = fopen(fname, "r");
	if (f == NULL)
		err(errno, NULL);

	memset(tasks, 0, sizeof(struct task) * MAXPROC);
	while (!feof(f)) {
		int i, n, m;
		char *p;
		char *token;
		const char *delim = ",";
		fscanf(f, "%ms", &p);
		/* Alternativa:
		#define MAXLINE 256
		const char *delim = ",\n";
		char linebuf[MAXLINE];
		fgets(linebuf, MAXLINE, f);
		p = linebuf;
		*/
		token = strsep(&p, delim);
		i = 0;
		while (token != NULL && *token != 0) {
			n = strtol(token, NULL, 10);
			/* Alternativa:
			sscanf(token, "%d", &n);
			*/
			if (i == 0) {
				m = n;
				tasks[m].valid = 1;
				tasks[m].id = m;
			} else if (i > 1) {
				tasks[n].next[m] = 1;
			}
			i++;
			token = strsep(&p, delim);
		}
	}
	fclose(f);
}

#else

void parse_graph(char *fname, struct task *tasks)
{
	FILE *f;

	f = fopen(fname, "r");
	if (f == NULL)
		err(errno, NULL);

	memset(tasks, 0,  sizeof(struct task) * MAXPROC);
	while (!feof(f)) {
		int n, m, i, k;
		fscanf(f, "%d,%d ", &m, &n);
		tasks[m].valid = 1;
		tasks[m].id = m;
		for (i = 0; i < n; i++) {
			fscanf(f, ",%d ", &k);
			tasks[k].next[m] = 1;
		}
	}
	fclose(f);
}

#endif

void print_graph(struct task tasks[], int n)
{
	int i,j;

	for (i = 0; i < n; i++) {
		if (!tasks[i].valid)
			continue;
		printf("%d: ", tasks[i].id);
		for (j = 0; j < n; j++)
			if (tasks[i].next[j])
				printf("%d ", j);
		printf("\n");
	}
}

