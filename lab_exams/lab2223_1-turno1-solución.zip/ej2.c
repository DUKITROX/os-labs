#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <errno.h>
#include <sys/wait.h>
#include <pthread.h>
#include <semaphore.h>

#include "graph.h"

struct task tasks[MAXPROC];

#ifdef USE_MUTEX_VC
pthread_mutex_t m;
#endif


#ifdef USE_MUTEX_VC

void wait_for_predecesors(int id)
{
	int i;

	pthread_mutex_lock(&m);
	while (tasks[id].pred) {
//		printf("Task %d waiting\n", id);
		pthread_cond_wait(&tasks[id].wq, &m);
	}
	pthread_mutex_unlock(&m);
}

void notify_successors(int id)
{
	int i;

	pthread_mutex_lock(&m);
	for (i = 0; i < MAXPROC; i++)
		if (tasks[id].next[i]) {
			tasks[i].pred--;
//			printf("Task %d notifying task %d\n", id, i);
			pthread_cond_signal(&tasks[i].wq);
		}
	pthread_mutex_unlock(&m);
}

#else
void wait_for_predecesors(int id)
{
	int i;

	//wait for predecesors
	for (i = 0; i < tasks[id].pred; i++) {
//		printf("Task %d waiting\n", id);
		sem_wait(&tasks[id].s);
	}
}

void notify_successors(int id)
{
	int i;

	//signal successors
	for (i = 0; i < MAXPROC; i++)
		if (tasks[id].next[i]) {
//			printf("Task %d notifying task %d\n", id, i);
			sem_post(&tasks[i].s);
		}
}

#endif


void *task_body(void * arg)
{
	int id = *(int *)arg;

	wait_for_predecesors(id);

	printf("Task %d running\n", id);

	notify_successors(id);

	return NULL;
}

void create_tasks(struct task *tasks, int n)
{
	int i;

	for (i = 0; i < n; i++) {
		if (!tasks[i].valid)
			continue;

		pthread_create(&tasks[i].tid, NULL, task_body, &tasks[i].id);
	}
}

void join_tasks(struct task *tasks, int n)
{
	int i;

	for (i = 0; i < n; i++) {
		if (!tasks[i].valid)
			continue;

		pthread_join(tasks[i].tid, NULL);
	}
}

int main(int argc, char** argv)
{
	FILE *f;
	int i,j;

#ifndef STATIC_GRAPH
	if (argc < 2)
		errx(-1, "usage: %s filename", argv[0]);

	parse_graph(argv[1], tasks);
#else
	memcpy(tasks, tasks_static, sizeof(struct task) * MAXPROC);
#endif

#ifdef USE_MUTEX_VC
	pthread_mutex_init(&m, NULL);
#endif

	for (i = 0; i < MAXPROC; i++) {
		if (!tasks[i].valid)
			continue;
		// Inicialización de predecesores
		for (j = 0; j < MAXPROC; j++)
			if (tasks[i].next[j])
				tasks[j].pred++;
		// Inicialización de recursos de sincronización
#ifdef USE_MUTEX_VC
		pthread_cond_init(&tasks[i].wq, NULL);
#else
		sem_init(&tasks[i].s, 0, 0);
#endif
	}

	print_graph(tasks, MAXPROC);

	create_tasks(tasks, MAXPROC);
	join_tasks(tasks, MAXPROC);
}

