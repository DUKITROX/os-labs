#ifndef _GRAPH_H_
#define _GRAPH_H_

#include <semaphore.h>
#include <unistd.h>
#include <sys/types.h>

#define MAXPROC 16

struct task {
	int valid;
	int next[MAXPROC];
	int id;
	// resto de campos, depende de la solución que implementen
	pid_t pid;     // sólo para apartado 3 que hemos descartado
	pthread_t tid;
	int pred;     // común para las dos implementaciones
	// para implementación con semáforos
	sem_t s;
	// para implementación con mutex y vc
	pthread_cond_t wq;
};

void parse_graph(char *fname, struct task *tasks);
void print_graph(struct task tasks[], int n);

extern struct task tasks_static[MAXPROC];

#endif
