#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <errno.h>

#include "graph.h"

struct task tasks[MAXPROC];

int main(int argc, char** argv)
{
#ifndef STATIC_GRAPH
	if (argc < 2)
		errx(-1, "usage: %s filename", argv[0]);

	parse_graph(argv[1], tasks);
#else
	memcpy(tasks, tasks_static, sizeof(struct task) * MAXPROC);
#endif

	print_graph(tasks, MAXPROC);
}

