#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <err.h>

#define CAPACITY 3
#define VIPSTR(is_vip) (is_vip) ? "professor" : "student"

int num_clients = 0;
int clients_inside = 0;
int local_turn = 0;
int local_turn_vip = 0;
int global_turn = 0;
int global_turn_vip = 0;
int waiting_vip = 0;

pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t myturn = PTHREAD_COND_INITIALIZER;

typedef struct client_data
{
    int id;
    int myturn;
    int is_vip; // 0 es normal, 1 es vip.
} client_t;

//////////////////////////////
int is_vacation = 0;
//////////////////////////////

void arrive_client(client_t *client)
{
    pthread_mutex_lock(&m);

    client->myturn = (client->is_vip) ? local_turn_vip++ : local_turn++;
    printf("User %d (%s) waiting on the queue.\n", client->id, VIPSTR(client->is_vip));
    fflush(stdout);

    if (client->is_vip)
    {
        waiting_vip++;
        while (client->myturn != global_turn_vip || clients_inside >= CAPACITY || is_vacation)
        {
            pthread_cond_wait(&myturn, &m);
        }
    }
    else
    {
        while (waiting_vip || client->myturn != global_turn || clients_inside >= CAPACITY || is_vacation)
        {
            pthread_cond_wait(&myturn, &m);
        }
    }
    pthread_mutex_unlock(&m);
}

void enter_and_dance(client_t *client)
{
    pthread_mutex_lock(&m);
    clients_inside++;
    if (client->is_vip)
    {
        waiting_vip--;     // Uno menos esperando
        global_turn_vip++; // Siguiente turno
    }
    else
    {
        global_turn++; // Siguiente turno
    }
    int seconds = 2;
    printf("User %d (%s) is reading books for %d seconds.\n", client->id, VIPSTR(client->is_vip), seconds);
    fflush(stdout);
    pthread_cond_broadcast(&myturn);
    pthread_mutex_unlock(&m);
    sleep(seconds); // dance
}

void exit_client(client_t *client)
{
    pthread_mutex_lock(&m);
    clients_inside--;
    printf("User %d (%s) leaves the library.\n", client->id, VIPSTR(client->is_vip));
    fflush(stdout);
    pthread_cond_broadcast(&myturn);
    pthread_mutex_unlock(&m);
}

void *client_function(void *arg)
{
    client_t *client = (client_t *)arg;
    arrive_client(client);
    enter_and_dance(client);
    exit_client(client);
    return NULL;
}

//////////////////////////////
void *vacation_thread(void *arg) {
    while (1) {
        sleep(4); // Simulate time before vacation
        pthread_mutex_lock(&m);
        is_vacation = 1;
        printf("Library is closing for vacation.\n");
        pthread_mutex_unlock(&m);

        sleep(2); // Simulate vacation period

        pthread_mutex_lock(&m);
        is_vacation = 0;
        printf("Library is now open after vacation.\n");
        pthread_cond_broadcast(&myturn);
        pthread_mutex_unlock(&m);
    }
    return NULL;
}
///////////////////////////////
int main(int argc, char *argv[])
{
    int i, isvip;
    client_t *ca;
    pthread_t *tid;
    FILE *fs;

    if (argc != 2)
        errx(EXIT_FAILURE, "usage %s filename\n\tError: filename missing\n",
             argv[0]);

    fs = fopen(argv[1], "r");
    if (fs == NULL)
        err(EXIT_FAILURE, "Open file %s", argv[1]);

    if (fscanf(fs, "%d\n", &num_clients) != 1)
        err(EXIT_FAILURE, "parsing number of clients");

    tid = malloc(num_clients * sizeof(pthread_t));
    if (tid == NULL)
        err(EXIT_FAILURE, "malloc pthread_t");
    pthread_t vacation_tid;

    for (i = 0; i < num_clients; i++)
    {
        ca = malloc(sizeof(client_t));
        ca->id = i;
        if (fscanf(fs, "%d\n", &isvip) != 1)
            err(EXIT_FAILURE, "parsing vip nature of client %d", i);
        ca->is_vip = isvip;
        // printf("client %d is %s\n", i, VIPSTR(isvip));
        pthread_create(&tid[i], NULL, client_function, ca);
    }
    pthread_create(&vacation_tid, NULL, vacation_thread, NULL);

    fclose(fs);
    fs = NULL;

    for (i = 0; i < num_clients; i++)
        pthread_join(tid[i], NULL);
    pthread_cancel(vacation_tid);

    pthread_mutex_destroy(&m);
    pthread_cond_destroy(&myturn);
    free(tid);
    tid = NULL;

    return 0;
}
