#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <err.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>
#include <errno.h> //SOLUTION
#include <sys/wait.h> //SOLUTION
#include <stdbool.h> //SOLUTION

char *progname;

//SOLUTION
void process_hardlinks(char *dirname, char *filename, bool highres)
{
	pid_t pid;
	char path_orig[PATH_MAX];
	char path_dest[PATH_MAX];
	
	

	strncpy(path_orig, dirname, PATH_MAX);
	strncat(path_orig, filename, PATH_MAX - strlen(path_orig));
	strncpy(path_dest, dirname, PATH_MAX);
	if (highres){
		strncat(path_dest, "Folder_01/", PATH_MAX - strlen(path_dest));
	}else{
		strncat(path_dest, "Folder_02/", PATH_MAX - strlen(path_dest));
	}
	strncat(path_dest, filename, PATH_MAX - strlen(path_dest));
	
	struct stat sb;

	if (lstat(path_orig, &sb) < 0) {
		warn("stat of %s", path_orig);		
	}

	if ((sb.st_mode & S_IFMT) != S_IFDIR) {
		char *ext = strrchr(path_orig,'.');
		if (ext !=NULL && strcmp(ext,".png") == 0) {
			if ((pid = fork()) < 0) {
				err(errno, "fork");
			}	 

			if (pid == 0) {
				
				int status = link(path_orig, path_dest);
				if (status == -1){
					printf("Error while creating the link\n");
					exit(EXIT_FAILURE);
				}else{
					printf("Link to %s created successfully\n", path_orig);
					exit(EXIT_SUCCESS);
				}
				
				
			} else { // > 0
				waitpid(pid, NULL, 0);
			}
		}
	}
}
//END SOLUTION

void usage(void)
{
	printf("%s file1 [file2 [file3 ...]]\n", progname);
}

int get_size_dir(char *fname, size_t *blocks);

int get_size(char *fname, size_t *blocks)
{
	struct stat sb;

	if (lstat(fname, &sb) < 0) {
		warn("stat of %s", fname);
		return -1;
	}

	*blocks = 0;

	if ((sb.st_mode & S_IFMT) == S_IFDIR) {
		get_size_dir(fname, blocks);
	}

	*blocks += sb.st_blocks;

	return 0;
}

int get_size_dir(char *dname, size_t *blocks)
{
	DIR *d;
	char *fname;
	size_t len, fblocks;
	struct dirent  *de;
	int retv = 0;

	d = opendir(dname);

	if (d == NULL) {
		warn("opendir on %s", dname);
		return -1;
	}

	*blocks = 0;

	while ((de = readdir(d)) != NULL) {
		if (!strcmp(".", de->d_name) || !strcmp("..", de->d_name))
			continue;

		len = strlen(dname) + strlen(de->d_name) + 2;
		fname = malloc(len);
		if (fname == NULL) {
			warn("malloc of %ld bytes", (long)len);
			retv = -1;
			break;
		}		
		snprintf(fname, len, "%s/%s", dname, de->d_name);
		if (get_size(fname, &fblocks) < 0) {
			warn("could not get size for file %s", fname);
		} else {
			*blocks += fblocks;
		}
		free(fname);
	}

	closedir(d);
	return retv;
}

int main(int argc, char *argv[])
{
	int i;
	progname = argv[0];
	size_t blocks;
	//SOLUTION
	char *dirname = "./";
	bool highres = true;
	//END SOLUTION
	if (argc < 2) {
		usage();
		exit(EXIT_FAILURE);
	}

	i = 1;

	while (argv[i] != NULL) {
		get_size(argv[i], &blocks);
		printf("%lluK\t%s\n", (long long unsigned) (blocks * 512) / 1024,  argv[i]);
		//SOLUTION
		highres = true;
		if (blocks<600){
			highres = false;
		}
		process_hardlinks(dirname,argv[i],highres);
		//END SOLUTION
		i++;

	}

	return 0;
}
