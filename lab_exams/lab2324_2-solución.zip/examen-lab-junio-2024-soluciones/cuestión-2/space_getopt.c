#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <err.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>
#include <errno.h> //SOLUTION
#include <sys/wait.h> //SOLUTION
#include <stdbool.h> //SOLUTION

char *progname;

//SOLUTION
struct options {
	char* output_small_files;
	char* output_large_files;
	int threshold;
};

void process_hardlinks(char *dirname, char *dirdest, char *filename)
{
	pid_t pid;
	char path_orig[PATH_MAX];
	char path_dest[PATH_MAX];
	
	

	strncpy(path_orig, dirname, PATH_MAX);
	strncat(path_orig, "/", PATH_MAX - strlen(path_orig));
	strncat(path_orig, filename, PATH_MAX - strlen(path_orig));
	strncpy(path_dest, dirname, PATH_MAX);
	strncat(path_dest, "/", PATH_MAX - strlen(path_orig));
	strncat(path_dest, dirdest, PATH_MAX - strlen(path_dest));
	strncat(path_dest, filename, PATH_MAX - strlen(path_dest));
	
	struct stat sb;

	if (lstat(path_orig, &sb) < 0) {
		warn("stat of %s", path_orig);		
	}

	if ((sb.st_mode & S_IFMT) != S_IFDIR) {
		char *ext = strrchr(path_orig,'.');
		if (ext !=NULL && strcmp(ext,".png") == 0) {
			if ((pid = fork()) < 0) {
				err(errno, "fork");
			}	 

			if (pid == 0) {
				int status = link(path_orig, path_dest);
				if (status == -1){
					printf("Error while creating the link\n");
					exit(EXIT_FAILURE);
				}else{
					printf("Link to %s created successfully\n", path_orig);
					exit(EXIT_SUCCESS);
				}				
			} else { // > 0
				waitpid(pid, NULL, 0);
			}
		}
	}
}
//END SOLUTION

void usage(void)
{
	printf("%s file1 [file2 [file3 ...]]\n", progname);
}

int get_size_dir(char *fname, size_t *blocks);

int get_size(char *fname, size_t *blocks)
{
	struct stat sb;

	if (lstat(fname, &sb) < 0) {
		warn("stat of %s", fname);
		return -1;
	}

	*blocks = 0;

	if ((sb.st_mode & S_IFMT) == S_IFDIR) {
		get_size_dir(fname, blocks);
	}

	*blocks += sb.st_blocks;

	return 0;
}

int get_size_dir(char *dname, size_t *blocks)
{
	DIR *d;
	char *fname;
	size_t len, fblocks;
	struct dirent  *de;
	int retv = 0;

	d = opendir(dname);

	if (d == NULL) {
		warn("opendir on %s", dname);
		return -1;
	}

	*blocks = 0;

	while ((de = readdir(d)) != NULL) {
		if (!strcmp(".", de->d_name) || !strcmp("..", de->d_name))
			continue;

		len = strlen(dname) + strlen(de->d_name) + 2;
		fname = malloc(len);
		if (fname == NULL) {
			warn("malloc of %ld bytes", (long)len);
			retv = -1;
			break;
		}		
		snprintf(fname, len, "%s/%s", dname, de->d_name);
		if (get_size(fname, &fblocks) < 0) {
			warn("could not get size for file %s", fname);
		} else {
			*blocks += fblocks;
		}
		free(fname);
	}

	closedir(d);
	return retv;
}

int main(int argc, char *argv[])
{
	//SOLUTION
	int opt;
	struct options options;
	options.output_large_files = NULL;
	options.output_small_files = NULL;
	options.threshold = 300;
	//END SOLUTION
		
	int i;
	int args_opt=0;
	progname = argv[0];
	size_t blocks;
	//SOLUTION
	char dirname[PATH_MAX];
	getcwd(dirname,sizeof(dirname));
	char *dirdest;	
	bool highres = true;
	//END SOLUTION
	if (argc < 2) {
		usage();
		exit(EXIT_FAILURE);
	}

	while ((opt = getopt(argc, argv, "ht:l:s:")) != -1)
	{
		switch (opt)
		{
		case 'h':
			fprintf(stderr, "Usage: %s [ -h | -t (DEFAULT threshold = 300) -l out_large_files -s out_small_files ]\n", argv[0]);
			exit(EXIT_SUCCESS);
		case 't':
			options.threshold = atoi(optarg);
			args_opt++;
			break;
		case 'l':
			options.output_large_files = optarg;
			args_opt++;
			break;
		case 's':
			options.output_small_files = optarg;
			args_opt++;
			break;
		default:
			exit(EXIT_FAILURE);
		}
	}

	if (options.output_large_files == NULL || options.output_small_files == NULL )
	{
		fprintf(stderr, "Must specify the threshold and two output directories\n");
		exit(EXIT_FAILURE);
	}
	
	printf("The output dir for small files is %s \n", options.output_small_files);
	printf("The output dir for large files is %s \n", options.output_large_files);
	printf("The threshold is %d\n", options.threshold);
	printf("The number of args is %d\n", args_opt);
	
	i = 1+args_opt*2;

	while (argv[i] != NULL) {
		get_size(argv[i], &blocks);
		printf("%lluK\t%s\n", (long long unsigned) (blocks * 512) / 1024,  argv[i]);
		//SOLUTION
		highres = true;
		dirdest = options.output_large_files;	
		if (((blocks * 512) / 1024)<options.threshold){
			highres = false;
			dirdest = options.output_small_files;
		}
		process_hardlinks(dirname, dirdest, argv[i]);
		//END SOLUTION
		i++;

	}

	return 0;
}
