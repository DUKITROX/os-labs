#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <err.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <dirent.h>
#include <errno.h>

struct options {
	char *progname;
	int recurse;
};

struct options opt;

void usage(void)
{
	printf("%s [options] [dirname]\n\n", opt.progname);
	printf("lists the contents of dirname (default .)\n");
	printf("options:\n"
		"\t-h:\tshow this help\n"
		"\t-R:\trecursive\n"
	);
}

void list_dir(char *name)
{
	DIR *d;
	struct dirent *de;
	struct stat *st;

	d = opendir(name);
	while ((de = readdir(d)) != NULL) {
		printf("%s\n", de->d_name);
	}
}

void process_recurse(char *dirname, char *name)
{
	pid_t pid;
	char path[PATH_MAX];

	strncpy(path, dirname, PATH_MAX);
	strncat(path, "/", PATH_MAX - strlen(path));
	strncat(path, name, PATH_MAX - strlen(path));

	if ((pid = fork()) < 0) {
		err(errno, "fork");
	} 

	if (pid == 0) {
		execl(opt.progname, opt.progname, "-R", path, NULL);
		err(errno, "execl");
	} else { // > 0
		waitpid(pid, NULL, 0);
	}
}

void list_dir_recurse(char *name)
{
	DIR *d;
	struct dirent *de;
	struct stat *st;

	d = opendir(name);
	while ((de = readdir(d)) != NULL) {
		if (de->d_type != DT_DIR || 
			!strcmp(de->d_name, ".") ||
			!strcmp(de->d_name, ".."))
			continue;
		printf("\n");
		process_recurse(name, de->d_name);
	}
}

int main(int argc, char **argv)
{
	char *dirname = ".";
	opt.progname = argv[0];
	opt.recurse = 0;
	int o;

	while((o = getopt(argc, argv, "hR")) != -1) {
		switch (o) {
			case 'h':
				usage();
				exit(EXIT_SUCCESS);
			break;
			case 'R':
				opt.recurse = 1;
		}
	}

	if (argc - optind > 0)
		dirname  = argv[optind];

	if (opt.recurse)
		printf("%s:\n", dirname);

	list_dir(dirname);

	if (opt.recurse)
		list_dir_recurse(dirname);

	return 0;
}
