#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <errno.h>
#include <err.h>

#define NTH 10

int turn = 0;
int position = 0;
int ready = 0;
pthread_t thid[NTH];

pthread_mutex_t m;
pthread_cond_t start, my_turn;

void change_clothes(int id)
{
	printf("Runner %d is changing clothes\n", id);
	sleep(1 + (rand() % 3));
}

void move_position(int id, int pos)
{
	sleep(1 + (rand() % (1 + pos)));
	printf("Runner %d reaches its starting position %d\n", id, pos);
}

void run(int id, int pos)
{
	printf("Runner %d running from position %d\n", id, pos);
	sleep(1 + (rand() % 3));
}

int get_position(int id)
{
	int pos;
	pthread_mutex_lock(&m);
	pos = position++;
	pthread_mutex_unlock(&m);
	return pos;
}

void wait_all_ready(int id)
{
	pthread_mutex_lock(&m);
	ready++;
	while (ready < NTH)
		pthread_cond_wait(&start, &m);
	pthread_cond_broadcast(&start);
	pthread_mutex_unlock(&m);
}

void wait_my_turn(int id, int pos)
{
	pthread_mutex_lock(&m);
	while (turn != pos)
		pthread_cond_wait(&my_turn, &m);
	pthread_mutex_unlock(&m);
}

void pass_on_relay(int id)
{
	pthread_mutex_lock(&m);
	turn++;
	pthread_cond_broadcast(&my_turn);
	pthread_mutex_unlock(&m);
}

void *thmain(void *arg)
{
	int id = (int) (long long) arg;
	int pos;

	change_clothes(id);
	pos = get_position(id);
	move_position(id, pos);
	wait_all_ready(id);
	wait_my_turn(id, pos);
	run(id, pos);
	pass_on_relay(id);
	
	return NULL;
}

int main(int argc, char *argv[])
{
	int i;

	pthread_mutex_init(&m, NULL);
	pthread_cond_init(&start, NULL);
	pthread_cond_init(&my_turn, NULL);

	for (i = 0; i < NTH; i++) {
		pthread_create(&thid[i], NULL, thmain, (void *) (long long) i);
	}

	for (i = 0; i < NTH; i++) {
		pthread_join(thid[i], NULL);
	}

	return EXIT_SUCCESS;
}
