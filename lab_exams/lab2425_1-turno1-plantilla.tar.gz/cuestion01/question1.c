#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <err.h>
#include <sys/stat.h>


// Function to compare binary files
void run_sh_script(const char *old_file, const char *new_file) {
    char command[512];
    snprintf(command, sizeof(command), 
             "sh -c 'if cmp --silent -- \"%s\" \"%s\"; then echo \"Binary files contents are identical\"; else echo \"Binary files are different\"; fi'", 
             old_file, new_file);
    system(command);
}

// Function to run binary file generation and comparison 
void run_bin_option(const char *old_file, const char *new_file) {

}

// Function to run text output generation option
void run_text_option() {

}

// Function to run both binary and text output generation options
void run_all_option(const char *old_file, const char *new_file) {

}


int main(int argc, char *argv[]) {

}

