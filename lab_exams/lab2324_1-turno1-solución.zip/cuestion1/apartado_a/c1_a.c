#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <err.h>
#include <unistd.h>
#include <sys/wait.h>
#include <ctype.h>

#define MAXLINE 1024

int setargs(char *args, char **argv)
{
	int count = 0;

	while (*args && isspace(*args))
		args++;
	while (*args) {
		if (argv)
			argv[count] = args;
		count++;
		while (*args && !isspace(*args))
			args++;
		while (*args && isspace(*args)) {
			if (argv)
				*args = '\0';
			args++;
		}
	}

	return count;
}

int main(int argc, char **argv)
{
	FILE *in = stdin;
	char line[] = "ls -l    -t";
	int cargc;
	char **cargv;

	if (argc > 1)
		errx(EXIT_FAILURE, "usage: %s");

	cargc = setargs(line, NULL);
	cargv = malloc((cargc + 1) * sizeof(char *));
	if (cargv == NULL)
		err(EXIT_FAILURE, "argv malloc");
	setargs(line, cargv);
	cargv[cargc] = NULL;

	for (int i = 0; i < cargc; i++)
		printf("argv[%d] = %s\n", i, cargv[i]);

	return 0;
}
