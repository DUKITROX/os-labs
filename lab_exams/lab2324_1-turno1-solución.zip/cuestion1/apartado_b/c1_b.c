#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <err.h>
#include <unistd.h>
#include <sys/wait.h>
#include <ctype.h>

#define MAXLINE 1024

int setargs(char *args, char **argv)
{
	int count = 0;

	while (*args && isspace(*args))
		args++;
	while (*args) {
		if (argv)
			argv[count] = args;
		count++;
		while (*args && !isspace(*args))
			args++;
		while (*args && isspace(*args)) {
			if (argv)
				*args = '\0';
			args++;
		}
	}

	return count;
}

int main(int argc, char **argv)
{
	FILE *in = stdin;
	char linebuf[MAXLINE];
	char *line = NULL;
	const char *PROMPT = "sshell # ";

	if (argc > 2)
		errx(EXIT_FAILURE, "usage: %s [filename]");

	if (argc == 2) {
		in = fopen(argv[1], "r");
		if (in ==  NULL)
			err(EXIT_FAILURE, "opening file: %s", argv[1]);
	}

	if (in == stdin)
		printf("%s", PROMPT);
	while (line = fgets(linebuf, MAXLINE, in)) {
		int cargc = setargs(line, NULL);
		char **cargv = malloc((cargc + 1) * sizeof(char *));
		pid_t pid;
		if (cargv == NULL)
			err(EXIT_FAILURE, "argv malloc");
		setargs(line, cargv);
		cargv[cargc] = NULL;

		pid = fork();
		if (pid == 0) {
			execvp(cargv[0], cargv);
			err(EXIT_FAILURE, "execvp");
		} else if (pid > 0) {
			waitpid(pid, NULL, 0);
			free(cargv);
			if (in == stdin)
				printf("%s", PROMPT);
		} else {
			err(EXIT_FAILURE, "fork");
		}
	}

	if (in != stdin)
		fclose(in);

	return 0;
}
