#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <err.h>

#define CAPACITY 5

char * vipstr[] = {
	"normal ",
	"  vip  ",
	"special"
};

int num_clients = 0;
int nturn = 0;
int nticket = 0;
int vturn = 0;
int vticket = 0;
int sturn = 0;
int sticket = 0;

int num_clients_inside = 0;
int vip_waiting = 0;
int special_waiting = 0;
int num_special_inside = 0;

pthread_mutex_t m;
pthread_cond_t empty;

typedef struct {
	int id;
	int type;
} client_arg_t;


void enter_normal_client(int id)
{
	int myticket;

	pthread_mutex_lock(&m);
	myticket = nticket++;
	while (myticket != nturn || vip_waiting || num_clients_inside >= CAPACITY ||
			special_waiting || num_special_inside) {
		printf("Client %2d (%s) waiting on the queue\n", id, vipstr[0]);
		pthread_cond_wait(&empty, &m);
	}
	num_clients_inside++;
	nturn++;
	pthread_cond_broadcast(&empty);
	printf("Client %2d (%s) entering the disco\n", id, vipstr[0]);
	pthread_mutex_unlock(&m);
}

void enter_vip_client(int id)
{
	int myticket;

	pthread_mutex_lock(&m);
	myticket = vticket++;
	while (myticket != vturn || num_clients_inside >= CAPACITY ||
			special_waiting || num_special_inside) {
		vip_waiting++;
		printf("Client %2d (%s) waiting on the queue\n", id, vipstr[1]);
		pthread_cond_wait(&empty, &m);
		vip_waiting--;
	}
	num_clients_inside++;
	vturn++;
	pthread_cond_broadcast(&empty);
	printf("Client %2d (%s) entering the disco\n", id, vipstr[1]);
	pthread_mutex_unlock(&m);
}

void enter_special_client(int id)
{
	int myticket;

	pthread_mutex_lock(&m);
	myticket = sticket++;
	while (myticket != sturn || num_clients_inside > 0 || 
			num_special_inside >= CAPACITY) {
		special_waiting++;
		printf("Client %2d (%s) waiting on the queue\n", id, vipstr[2]);
		pthread_cond_wait(&empty, &m);
		special_waiting--;
	}
	num_special_inside++;
	sturn++;
	pthread_cond_broadcast(&empty);
	printf("Client %2d (%s) entering the disco\n", id, vipstr[2]);
	pthread_mutex_unlock(&m);
}

void dance(int id, int type)
{
	printf("Client %2d (%s) dancing in disco\n", id, vipstr[type]);
	sleep((rand() % 3) + 1);
}

void disco_exit(int id, int type)
{
	int myticket;

	pthread_mutex_lock(&m);
	if (type != 2)
		num_clients_inside--;
	else
		num_special_inside--;
	pthread_cond_broadcast(&empty);
	printf("Client %2d (%s) exits the disco\n", id, vipstr[type]);
	pthread_mutex_unlock(&m);
}

void *client(void *arg)
{
	client_arg_t *pca = (client_arg_t *)arg;

	printf("Starting client %2d\n", pca->id, vipstr[pca->type]);

	switch (pca->type) {
	case 0:
		enter_normal_client(pca->id);
		break;
	case 1:
		enter_vip_client(pca->id);
		break;
	case 2:
		enter_special_client(pca->id);
		break;
	defualt:
		errx(EXIT_FAILURE, "not valid type: %d", pca->type);
	}
	dance(pca->id, pca->type);
	disco_exit(pca->id, pca->type);

	free(pca);

	return NULL;
}

int main(int argc, char *argv[])
{
	int i,type;
	client_arg_t *ca;
	pthread_t *tid;
	FILE* fs;

	if (argc != 2)
		errx(EXIT_FAILURE, "usage %s filename\n\tError: filename missing\n",
				argv[0]);

	fs = fopen(argv[1], "r");
	if (fs == NULL)
		err(EXIT_FAILURE, "Open file %s", argv[1]);

	if (fscanf(fs, "%d\n", &num_clients) != 1)
		err(EXIT_FAILURE, "parsing number of clients");

	tid = malloc(num_clients * sizeof(pthread_t));
	if (tid == NULL)
		err(EXIT_FAILURE, "malloc pthread_t");

	pthread_mutex_init(&m, NULL);
	pthread_cond_init(&empty, NULL);

	for (i = 0; i < num_clients; i++) {
		ca = malloc(sizeof(client_arg_t));
		ca->id = i;
		if (fscanf(fs, "%d\n", &type) != 1)
			err(EXIT_FAILURE, "parsing vip nature of client %d", i);
		ca->type = type;
		printf("client %d is %s\n", i, vipstr[type]);
		pthread_create(&tid[i], NULL, client, ca);
	}

	fclose(fs);
	fs = NULL;

	for (i = 0; i < num_clients; i++)
		pthread_join(tid[i], NULL);

	pthread_mutex_destroy(&m);
	pthread_cond_destroy(&empty);
	free(tid);
	tid = NULL;

	return 0;
}
