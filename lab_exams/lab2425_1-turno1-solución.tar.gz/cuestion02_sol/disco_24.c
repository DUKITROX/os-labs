#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <err.h>

#define CAPACITY 5
#define DANCEFLOOR_CAPACITY 2 // NEW FOR EXAM

#define VIPSTR(vip) ((vip) ? "  vip  " : "not vip")

int num_clients = 0;
int nturn = 0;
int nticket = 0;
int vturn = 0;
int vticket = 0;

int num_clients_inside = 0;
int vip_waiting = 0;

int dancefloor1 = 0, dancefloor2 = 0;  // NEW FOR EXAM

pthread_mutex_t m;
pthread_cond_t empty;
pthread_cond_t dancefloor_cond1;  // NEW FOR EXAM
pthread_cond_t dancefloor_cond2;  // NEW FOR EXAM

typedef struct {
    int id;
    int isvip;
    int dancefloor;  // NEW FOR EXAM
} client_arg_t;


void enter_normal_client(int id) {
    int myticket;

    pthread_mutex_lock(&m);
    myticket = nticket++;
    while (myticket != nturn || vip_waiting || num_clients_inside >= CAPACITY) {
        printf("Myticket %2d Nturn %2d \n", myticket, nturn);
        printf("Client %2d (not vip) waiting on the queue\n", id);
        pthread_cond_wait(&empty, &m);
    }
    num_clients_inside++;
    nturn++;
    pthread_cond_broadcast(&empty);
    printf("Client %2d (not vip) entering the disco\n", id);
    pthread_mutex_unlock(&m);
}

void enter_vip_client(int id) {
    int myticket;

    pthread_mutex_lock(&m);
    myticket = vticket++;
    while (myticket != vturn || num_clients_inside >= CAPACITY) {
        vip_waiting++;
        printf("Client %2d (  vip  ) waiting on the queue\n", id);
        pthread_cond_wait(&empty, &m);
        vip_waiting--;
    }
    num_clients_inside++;
    vturn++;
    pthread_cond_broadcast(&empty);
    printf("Client %2d (  vip  ) entering the disco\n", id);
    pthread_mutex_unlock(&m);
}

void dance(int id, int isvip, int assigned_floor) {
    pthread_mutex_lock(&m);

    // NEW FOR EXAM
    while ((assigned_floor == 1 && dancefloor1 >= DANCEFLOOR_CAPACITY) ||
           (assigned_floor == 2 && dancefloor2 >= DANCEFLOOR_CAPACITY)) {
        printf("Client %2d (%s) waiting for Dancefloor %d\n", id, VIPSTR(isvip), assigned_floor);

        if (assigned_floor == 1) {
            pthread_cond_wait(&dancefloor_cond1, &m);
        } else {
            pthread_cond_wait(&dancefloor_cond2, &m);
        }
    }

    if (assigned_floor == 1) {
        dancefloor1++;
        printf("Client %2d (%s) dancing on Dancefloor 1\n", id, VIPSTR(isvip));
    } else {
        dancefloor2++;
        printf("Client %2d (%s) dancing on Dancefloor 2\n", id, VIPSTR(isvip));
    }

    pthread_mutex_unlock(&m);

    sleep((rand() % 3) + 1);
}

void disco_exit(int id, int isvip, int assigned_floor) {
    pthread_mutex_lock(&m);
    num_clients_inside--;
    // NEW FOR EXAM
    if (assigned_floor == 1) {
        dancefloor1--;  
        pthread_cond_signal(&dancefloor_cond1);  
    } else {
        dancefloor2--;  
        pthread_cond_signal(&dancefloor_cond2);  
    }

    pthread_cond_broadcast(&empty);  

    printf("Client %2d (%s) exits the disco\n", id, VIPSTR(isvip));

    pthread_mutex_unlock(&m);
}

void *client(void *arg) {
    client_arg_t *pca = (client_arg_t *)arg;

    printf("Starting client %2d\n", pca->id);

    if (pca->isvip)
        enter_vip_client(pca->id);
    else
        enter_normal_client(pca->id);

    // NEW FOR EXAM
    dance(pca->id, pca->isvip, pca->dancefloor);

    // NEW FOR EXAM
    disco_exit(pca->id, pca->isvip, pca->dancefloor);

    free(pca);

    return NULL;
}

int main(int argc, char *argv[]) {
    int i, isvip, dancefloor;
    client_arg_t *ca;
    pthread_t *tid;
    FILE *fs;

    if (argc != 2)
        errx(EXIT_FAILURE, "usage %s client_file\n", argv[0]);

    fs = fopen(argv[1], "r");
    if (fs == NULL)
        err(EXIT_FAILURE, "Open file %s", argv[1]);

    if (fscanf(fs, "%d\n", &num_clients) != 1)
        err(EXIT_FAILURE, "parsing number of clients");

    tid = malloc(num_clients * sizeof(pthread_t));
    if (tid == NULL)
        err(EXIT_FAILURE, "malloc pthread_t");

    pthread_mutex_init(&m, NULL);
    pthread_cond_init(&empty, NULL);
    pthread_cond_init(&dancefloor_cond1, NULL);  // NEW FOR EXAM
    pthread_cond_init(&dancefloor_cond2, NULL);  // NEW FOR EXAM

    for (i = 0; i < num_clients; i++) {
        ca = malloc(sizeof(client_arg_t));
        ca->id = i;
        if (fscanf(fs, "%d %d\n", &isvip, &dancefloor) != 2)
            err(EXIT_FAILURE, "parsing vip nature of client %d", i);
        ca->isvip = isvip;
        ca->dancefloor = dancefloor;
        printf("client %d is %s and assigned to Dancefloor %d\n", i, VIPSTR(isvip), dancefloor);
        pthread_create(&tid[i], NULL, client, ca);
    }

    fclose(fs);
    fs = NULL;

    for (i = 0; i < num_clients; i++)
        pthread_join(tid[i], NULL);

    pthread_mutex_destroy(&m);
    pthread_cond_destroy(&empty);
    pthread_cond_destroy(&dancefloor_cond1);  // NEW FOR EXAM
    pthread_cond_destroy(&dancefloor_cond2);  // NEW FOR EXAM
    free(tid);
    tid = NULL;

    return 0;
}
