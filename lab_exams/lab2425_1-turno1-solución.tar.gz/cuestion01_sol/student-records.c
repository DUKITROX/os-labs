#include <stdio.h>
#include <unistd.h> /* for getopt() */
#include <stdlib.h> /* for EXIT_SUCCESS, EXIT_FAILURE */
#include <string.h>
#include "defs.h"

/**
 * @brief  Make a copy of existing string allocating memory accordingly
 *
 * @param original
 * @return new string that is a clone of original
 **/
static inline char *clone_string(char *original)
{
	char *copy;
	copy = malloc(strlen(original) + 1);
	strcpy(copy, original);
	return copy;
}

/** Loads a string from a file.
 *
 * file: pointer to the FILE descriptor
 *
 * The loadstr() function must allocate memory from the heap to store
 * the contents of the string read from the FILE.
 * Once the string has been properly built in memory, the function returns
 * the starting address of the string (pointer returned by malloc())
 *
 * Returns: !=NULL if success, NULL if error
 */
char *loadstr(FILE *file)
{
	int n, size = 0;
	char *buf;

	do
	{
		n = getc(file);
		size++;
	} while ((n != (int)'\0') && (n != EOF));

	if (n == EOF)
		return NULL;

	if ((buf = (char *)malloc(size)) == NULL)
		return NULL;

	fseek(file, -size, SEEK_CUR);

	fread(buf, 1, size, file);

	return buf;
}

#define MAXLEN_LINE_FILE 100

int print_text_file(char *path)
{
	FILE *file;
	int nr_records = 0;
	char buf[MAXLEN_LINE_FILE + 1];
	int i;
	student_t entry;
	char *lineptr;
	char *token;
	token_id_t token_id;
	int retval = 0;

	if (!(file = fopen(path, "r")))
	{
		perror("Cannot open input file\n");
		exit(EXIT_FAILURE);
	}

	/* Read record count */
	fgets(buf, MAXLEN_LINE_FILE, file);
	if (sscanf(buf, "%d", &nr_records) != 1)
	{
		perror("Failed to read register count\n");
		retval = EXIT_FAILURE;
		goto err_path;
	}

	for (i = 0; i < nr_records; i++)
	{
		if (feof(file) || fgets(buf, MAXLEN_LINE_FILE, file) == NULL)
		{
			perror("Failed to read line\n");
			retval = EXIT_FAILURE;
			goto err_path;
		}

		/* Remove line break */
		buf[strlen(buf) - 1] = '\0';
		lineptr = buf;
		token_id = STUDENT_ID_IDX;

		while ((token = strsep(&lineptr, ":")) != NULL)
		{
			switch (token_id)
			{
			case STUDENT_ID_IDX:
				if (sscanf(token, "%d", &entry.student_id) != 1)
				{
					fprintf(stderr, "Couldn't parse student ID field in record %d. token is %s\n", i + 1, token);
					retval = EXIT_FAILURE;
					goto err_path;
				}

				break;
			case NIF_IDX:
				strcpy(entry.NIF, token);
				break;
			case FIRST_NAME_IDX:
				entry.first_name = clone_string(token);
				break;
			case LAST_NAME_IDX:
				entry.last_name = clone_string(token);
				break;
			default:
				break;
			}
			token_id++;
		}

		if (token_id != NR_FIELDS_STUDENT)
		{
			fprintf(stderr, "Could not process all tokens from register %d\n", i + 1);
			retval = EXIT_FAILURE;
			goto err_path;
		}

		/* Dump contents */
		fprintf(stdout, "[Entry #%d]\n", i);
		fprintf(stdout, "\tstudent_id=%d\n\tNIF=%s\n\t"
						"first_name=%s\n\tlast_name=%s\n",
				entry.student_id, entry.NIF,
				entry.first_name, entry.last_name);
	}

err_path:
	fclose(file);
	return retval;
}

int write_binary_file(char *input_file, char *output_file)
{
	FILE *file, *students;
	int nr_records = 0;
	char buf[MAXLEN_LINE_FILE + 1];
	int i;
	student_t entry;
	char *lineptr;
	char *token;
	token_id_t token_id;
	int retval = 0;

	if (!(file = fopen(input_file, "r")))
	{
		fprintf(stderr, "The input file %s could not be opened: ",
				input_file);
		perror(NULL);
		exit(EXIT_FAILURE);
	}

	if (!(students = fopen(output_file, "w+")))
	{
		fprintf(stderr, "The output file %s could not be opened: ", optarg);
		perror(NULL);
		fclose(students);
		return (EXIT_FAILURE);
	}

	/* Read record count */
	fgets(buf, MAXLEN_LINE_FILE, file);
	if (sscanf(buf, "%d", &nr_records) != 1)
	{
		perror("Failed to read register count\n");
		retval = EXIT_FAILURE;
		goto err_path;
	}

	/* Write record count to output file */
	fwrite(&nr_records, sizeof(int), 1, students);

	for (i = 0; i < nr_records; i++)
	{
		if (feof(file) || fgets(buf, MAXLEN_LINE_FILE, file) == NULL)
		{
			perror("Failed to read line\n");
			retval = EXIT_FAILURE;
			goto err_path;
		}

		/* Remove line break */
		buf[strlen(buf) - 1] = '\0';
		lineptr = buf;
		token_id = STUDENT_ID_IDX;

		while ((token = strsep(&lineptr, ":")) != NULL)
		{
			switch (token_id)
			{
			case STUDENT_ID_IDX:
				if (sscanf(token, "%d", &entry.student_id) != 1)
				{
					fprintf(stderr, "Couldn't parse student ID field in record %d. token is %s\n", i + 1, token);
					retval = EXIT_FAILURE;
					goto err_path;
				}

				break;
			case NIF_IDX:
				strcpy(entry.NIF, token);
				break;
			case FIRST_NAME_IDX:
				entry.first_name = clone_string(token);
				break;
			case LAST_NAME_IDX:
				entry.last_name = clone_string(token);
				break;
			default:
				break;
			}
			token_id++;
		}

		if (token_id != NR_FIELDS_STUDENT)
		{
			fprintf(stderr, "Could not process all tokens from register %d\n", i + 1);
			retval = EXIT_FAILURE;
			goto err_path;
		}

		/* Dump contents */
		fwrite(&entry.student_id, sizeof(int), 1, students);
		fwrite(entry.NIF, 1, strlen(entry.NIF) + 1, students);
		fwrite(entry.first_name, 1, strlen(entry.first_name) + 1, students);
		fwrite(entry.last_name, 1, strlen(entry.last_name) + 1, students);
	}

	printf("%d student records writen successfully to binary file %s\n", nr_records, output_file);
err_path:
	fclose(file);
	fclose(students);
	return retval;
}

int print_binary_file(char *path)
{
	FILE *students;
	int nr_records = 0;
	int i;
	student_t entry;
	int retval = 0;

	if (!(students = fopen(path, "r")))
	{
		perror("Cannot open input file\n");
		exit(EXIT_FAILURE);
	}

	/* Read record count */
	if (fread(&nr_records, sizeof(unsigned int), 1, students) != 1)
	{
		fprintf(stderr, "Couldn't read nr_entries: ");
		perror(NULL);
		retval = EXIT_FAILURE;
		goto err_path;
	}

	for (i = 0; i < nr_records; i++)
	{
		char *temp;
		if (fread(&entry.student_id, sizeof(int), 1, students) != 1)
		{
			fprintf(stderr, "Couldn't read student id in student entry #%d\n", i);
			retval = EXIT_FAILURE;
			goto err_path;
		}

		if ((temp = loadstr(students)) == NULL)
		{
			fprintf(stderr, "Couldn't read student NIF in student entry #%d\n", i);
			retval = EXIT_FAILURE;
			goto err_path;
		}

		strcpy(entry.NIF, temp);
		free(temp);

		if ((entry.first_name = loadstr(students)) == NULL)
		{
			fprintf(stderr, "Couldn't read student first name in student entry #%d\n", i);
			retval = EXIT_FAILURE;
			goto err_path;
		}

		if ((entry.last_name = loadstr(students)) == NULL)
		{
			fprintf(stderr, "Couldn't read student last name in student entry #%d\n", i);
			retval = EXIT_FAILURE;
			goto err_path;
		}

		/* Dump contents */
		fprintf(stdout, "[Entry #%d]\n", i);
		fprintf(stdout, "\tstudent_id=%d\n\tNIF=%s\n\t"
						"first_name=%s\n\tlast_name=%s\n",
				entry.student_id, entry.NIF,
				entry.first_name, entry.last_name);
	}

err_path:
	fclose(students);
	return retval;
}

int main(int argc, char *argv[])
{
	int ret_code, opt;
	struct options options;

	/* Initialize default values for options */
	options.input_file = NULL;
	options.output_file = NULL;
	options.action = NONE_ACT;
	ret_code = 0;

	/* Parse command-line options */
	while ((opt = getopt(argc, argv, "hbpi:o:")) != -1)
	{
		switch (opt)
		{
		case 'h':
			fprintf(stderr, "Usage: %s [ -h | -p | -i infile | -o outfile | -b ]\n", argv[0]);
			exit(EXIT_SUCCESS);
		case 'p':
			options.action = PRINT_TEXT_ACT;
			break;
		case 'b':
			options.action = PRINT_BINARY_ACT;
			break;
		case 'o':
			options.output_file = optarg;
			break;
		case 'i':
			options.input_file = optarg;
			break;
		default:
			exit(EXIT_FAILURE);
		}
	}

	if (options.input_file == NULL)
	{
		fprintf(stderr, "Must specify one record file as an argument of -i\n");
		exit(EXIT_FAILURE);
	}

	if (options.action == NONE_ACT && (options.input_file) && (options.output_file))
	{
		options.action = WRITE_BINARY_ACT;
	}

	switch (options.action)
	{
	case NONE_ACT:
		fprintf(stderr, "Must indicate one of the following options: -o, -b \n");
		ret_code = EXIT_FAILURE;
		break;
	case PRINT_TEXT_ACT:
		ret_code = print_text_file(options.input_file);
		break;
	case PRINT_BINARY_ACT:
		ret_code = print_binary_file(options.input_file);
		break;
	case WRITE_BINARY_ACT:
		ret_code = write_binary_file(options.input_file, options.output_file);
		break;
	}
	exit(ret_code);
}
