#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <err.h>
#include <sys/stat.h>


typedef enum {
    NONE_ACT,
    TEXT_ACT, 
    BINARY_ACT, 
    ALL_ACT 
} actions_t;

// Function to compare binary files
void run_sh_script(const char *old_file, const char *new_file) {
    char command[512];
    snprintf(command, sizeof(command), 
             "sh -c 'if cmp --silent -- \"%s\" \"%s\"; then echo \"Binary files contents are identical\"; else echo \"Binary files are different\"; fi'", 
             old_file, new_file);
    system(command);
}

// Function to run binary file generation and comparison 
void run_bin_option(const char *old_file, const char *new_file) {
    pid_t pid;    
    if ((pid = fork()) == 0) {
        execlp("./student-records", "./student-records", "-i", "students-db.txt", "-o", new_file, (char *)NULL);
        perror("execlp failed");
        exit(EXIT_FAILURE);
    } else if (pid > 0) {
        waitpid(pid, NULL, 0); 
    } else {
        err(EXIT_FAILURE, "fork");
    }

    
    if ((pid = fork()) == 0) {
        run_sh_script(old_file, new_file);  
    } else if (pid > 0) {
        waitpid(pid, NULL, 0);
    } else {
        err(EXIT_FAILURE, "fork");
    }
}

// Function to run text output generation option
void run_text_option() {
    pid_t pid;    
    if ((pid = fork()) == 0) {
        execlp("./student-records", "./student-records", "-i", "students-db.txt", "-p", (char *)NULL);
        perror("execlp failed");
        exit(EXIT_FAILURE);
    } else if (pid > 0) {
        waitpid(pid, NULL, 0); 
    } else {
        err(EXIT_FAILURE, "fork");
    }
}

// Function to run both binary and text output generation options
void run_all_option(const char *old_file, const char *new_file) {
    pid_t pid_binary, pid_text;
    if ((pid_binary = fork()) == 0) {
        execlp("./student-records", "./student-records", "-i", "students-db.txt", "-o", new_file, (char *)NULL);
        perror("execlp failed");
        exit(EXIT_FAILURE);
    } else if (pid_binary > 0) {

    } else {
        err(EXIT_FAILURE, "fork");
    }

    if ((pid_text = fork()) == 0) {
        execlp("./student-records", "./student-records", "-i", "students-db.txt", "-p", (char *)NULL);
        perror("execlp failed");
        exit(EXIT_FAILURE);
    } else if (pid_text > 0) {
        
    } else {
        err(EXIT_FAILURE, "fork");
    }

    waitpid(pid_binary, NULL, 0); 
    waitpid(pid_text, NULL, 0);   

    pid_t pid_compare;
    if ((pid_compare = fork()) == 0) {
        run_sh_script(old_file, new_file);  
    } else if (pid_compare > 0) {
        waitpid(pid_compare, NULL, 0); 
    } else {
        err(EXIT_FAILURE, "fork");
    }
}


int main(int argc, char *argv[]) {
    int opt;
    actions_t action = NONE_ACT; 
    const char *old_file = NULL;
    const char *new_file = NULL;

    
    while ((opt = getopt(argc, argv, "hi:o:bta")) != -1) {
        switch (opt) {
            case 'h':
                fprintf(stderr, "Usage: %s [-b] [-t] [-a] -i <old_bin_file> -o <new_bin_file>\n", argv[0]);
                exit(EXIT_SUCCESS);
            case 'i': 
                old_file = optarg; 
                break;
            case 'o': 
                new_file = optarg; 
                break;
            case 'b':
                action = BINARY_ACT;  
                break;
            case 't':
                action = TEXT_ACT;  
                break;
            case 'a':
                action = ALL_ACT;  
                break;
            default:
                fprintf(stderr, "Usage: %s [-b] [-t] [-a] -i <old_bin_file> -o <new_bin_file>\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }

    
    switch (action) {
        case BINARY_ACT:
            if (!old_file || !new_file) {
                fprintf(stderr, "Error: One or both binary files do not exist\n");
                exit(EXIT_FAILURE);                
            }
            run_bin_option(old_file, new_file);
            break;
        case TEXT_ACT:
            run_text_option();
            break;
        case ALL_ACT:
            if (!old_file || !new_file) {
                fprintf(stderr, "Error: One or both binary files do not exist\n");
                exit(EXIT_FAILURE);                
            }
            run_all_option(old_file, new_file);
            break;
        case NONE_ACT:
            fprintf(stderr, "Error: No valid action specified. Use -b, -t, or -a.\n");
            exit(EXIT_FAILURE);
            break;
    }

    return 0;
}

