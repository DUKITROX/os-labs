#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <err.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>

/* ayudas para el apartado c **************************************/
#define TV_SEC(tv) ((tv).tv_sec)
#define TV_MSEC(tv) ((tv).tv_usec / 1000)

void timeval_diff(struct timeval *start, struct timeval *elapsed)
{
	elapsed->tv_sec -= start->tv_sec;
	if (elapsed->tv_usec < start->tv_usec) {
		elapsed->tv_sec--;
		elapsed->tv_usec += 1000000;
	}
	elapsed->tv_usec -= start->tv_usec;
}
/******************************************************************/

int run_command(char *cmd)
{
	pid_t pid;
	int saved_errno;
	int ret = 0, wstatus;

#if defined(APARTADO_B) || defined(APARTADO_C)
	struct sigaction saIgnore, saDefault;
	saIgnore.sa_handler = SIG_IGN;
	saIgnore.sa_flags = 0;
	sigemptyset(&saIgnore.sa_mask);
	sigaction(SIGINT, &saIgnore, NULL);
	sigaction(SIGTERM, &saIgnore, NULL);
#endif


	pid = fork ();
	if (pid < 0)
		err(EXIT_FAILURE, "fork");
	else if (pid == 0) {
#if defined(APARTADO_B) || defined(APARTADO_C)
		saDefault.sa_handler = SIG_DFL;
		saDefault.sa_flags = 0;
		sigemptyset(&saDefault.sa_mask);
		sigaction(SIGINT, &saDefault, NULL);
		sigaction(SIGTERM, &saDefault, NULL);
#endif

		execlp("/bin/sh", "/bin/sh", "-c", cmd, NULL);
		exit(errno);
	}

	printf("child process pid %d\n", pid);

	while (waitpid(pid, &wstatus, 0) == -1) {
		if (errno != EINTR) {
			ret = -1;
			break;
		}
	}

#if defined(APARTADO_B) || defined(APARTADO_C)
	saDefault.sa_handler = SIG_DFL;
	saDefault.sa_flags = 0;
	sigemptyset(&saDefault.sa_mask);
	sigaction(SIGINT, &saDefault, NULL);
	sigaction(SIGTERM, &saDefault, NULL);
#endif


#if defined(APARTADO_B) || defined(APARTADO_C)
	if (WIFSIGNALED(wstatus)) {
		printf("child with pid %d terminated by signal %d\n", pid, WTERMSIG(wstatus));
	}
#endif

	return ret;
}


int main(int argc, char **argv)
{
	int ret = 0;

	if (argc < 2) {
		errx(EXIT_FAILURE, "usage: %s command", argv[0]);
	}

#if defined(APARTADO_C)
	struct timeval start_tv, elap_tv;
	struct rusage ru;
	gettimeofday(&start_tv, NULL);
#endif

	ret = run_command(argv[1]);

	if (ret != 0) {
		perror("command error");
	}

#if defined(APARTADO_C)
	getrusage(RUSAGE_CHILDREN, &ru);
	gettimeofday(&elap_tv, NULL);
	timeval_diff(&start_tv, &elap_tv);
	printf("real: %ld.%03ld s\n", TV_SEC(elap_tv), TV_MSEC(elap_tv));
	printf("user: %ld.%03ld s\n", TV_SEC(ru.ru_utime), TV_MSEC(ru.ru_utime));
	printf("sys:  %ld.%03ld s\n", TV_SEC(ru.ru_stime), TV_MSEC(ru.ru_stime));
#endif

	return ret;
}
