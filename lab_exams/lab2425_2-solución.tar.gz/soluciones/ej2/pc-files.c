#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>

#define MAX_SBUFFER_SIZE 4
#define MAX_LINE_LENGTH 256

char *shared_buffer[MAX_SBUFFER_SIZE];
int count = 0, in = 0, out = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t not_empty = PTHREAD_COND_INITIALIZER;
pthread_cond_t not_full = PTHREAD_COND_INITIALIZER;

void *producer(void *arg) {
    FILE *input = (FILE *)arg;
    char line[MAX_LINE_LENGTH];

    while (fgets(line, MAX_LINE_LENGTH, input)) {
        char *data = malloc(strlen(line) + 1);
        strcpy(data, line);
        
        pthread_mutex_lock(&mutex);
        while (count == MAX_SBUFFER_SIZE) {
            pthread_cond_wait(&not_full, &mutex);
        }
        shared_buffer[in] = data;
        in = (in + 1) % MAX_SBUFFER_SIZE;
        count++;
        pthread_cond_signal(&not_empty);
        pthread_mutex_unlock(&mutex);
    }

    pthread_mutex_lock(&mutex);
    while (count == MAX_SBUFFER_SIZE) {
        pthread_cond_wait(&not_full, &mutex);
    }
    shared_buffer[in] = NULL;
    in = (in + 1) % MAX_SBUFFER_SIZE;
    count++;
    pthread_cond_signal(&not_empty);
    pthread_mutex_unlock(&mutex);

    return NULL;
}

void *consumer(void *arg) {
    FILE *output = (FILE *)arg;
    char *data;

    while (1) {
        pthread_mutex_lock(&mutex);
        while (count == 0) {
            pthread_cond_wait(&not_empty, &mutex);
        }
        data = shared_buffer[out];
        out = (out + 1) % MAX_SBUFFER_SIZE;
        count--;
        pthread_cond_signal(&not_full);
        pthread_mutex_unlock(&mutex);

        if (data == NULL) break;

        fprintf(output, "%s", data);
        free(data);
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    char *input_file = NULL, *output_file = NULL;
    FILE *input = stdin, *output = stdout;
    pthread_t prod_thread, cons_thread;
    int opt;

    while ((opt = getopt(argc, argv, "i:o:h")) != -1) {
        switch (opt) {
            case 'i':
                input_file = optarg;
                break;
            case 'o':
                output_file = optarg;
                break;
			case 'h':
            default:
                fprintf(stderr, "Uso: %s [-i fichero_entrada] [-o fichero_salida] [-h]\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }

    if (input_file) {
        input = fopen(input_file, "r");
        if (!input) {
            perror("Error abriendo fichero de entrada");
            return 1;
        }
    }

	if (output_file) {
		output = fopen(output_file, "w");
		if (!output) {
			perror("Error abriendo fichero de salida");
			return 1;
		}
	}

    pthread_create(&prod_thread, NULL, producer, input);
    pthread_create(&cons_thread, NULL, consumer, output);
    
    pthread_join(prod_thread, NULL);
    pthread_join(cons_thread, NULL);
    
    if (input_file) fclose(input);
	if (output_file) fclose(output);
    return 0;
}
